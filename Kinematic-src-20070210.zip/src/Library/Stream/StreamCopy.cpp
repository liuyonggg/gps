int StreamCopyDummy = 0;  // Provide a dummy entry point so librarian doesn't complain

