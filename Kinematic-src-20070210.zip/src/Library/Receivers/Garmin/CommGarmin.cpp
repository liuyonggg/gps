// An empty file. Create an entry point to keep the
//  librarian from printing a warning

int CommGarmin = 0;

